from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(CustomUser),
admin.site.register(WorkerProfile),
admin.site.register(CustomerProfile),
admin.site.register(Booking),
admin.site.register(Feedback),

