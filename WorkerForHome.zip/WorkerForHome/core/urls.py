from django.urls import path
from . import views

urlpatterns = [
    # Home + Search
    path("home/", views.home, name="home"),
    path("search/", views.search_workers, name="search_workers"),

    # Auth
    path("register/", views.register, name="register"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),

    # Worker Dashboard + Profile
    path("worker/dashboard/", views.worker_dashboard, name="worker_dashboard"),
    path("worker/profile/", views.worker_profile, name="worker_profile"),
    path("worker/profile/edit/", views.edit_worker_profile, name="edit_worker_profile"),
    path("worker/profile/delete/", views.delete_worker_profile, name="delete_worker_profile"),
    path("worker/status/update/", views.update_worker_status, name="update_worker_status"),

    # Worker Booking Actions
    path("worker/booking/<int:booking_id>/accept/", views.accept_booking, name="accept_booking"),
    path("worker/booking/<int:booking_id>/reject/", views.reject_booking, name="reject_booking"),
    path("worker/booking/<int:booking_id>/complete/", views.complete_booking, name="complete_booking"),

    # Customer Dashboard + Profile
    path("customer/dashboard/", views.customer_dashboard, name="customer_dashboard"),
    path("customer/profile/", views.customer_profile, name="customer_profile"),
    path("customer/profile/edit/", views.edit_customer_profile, name="edit_customer_profile"),

    # Worker views Customer Profile
    path("customer/<int:customer_id>/profile/", views.worker_view_customer_profile, name="worker_view_customer_profile"),

    # Booking + Feedback
    path("booking/<int:worker_id>/create/", views.create_booking, name="create_booking"),
    path("booking/<int:booking_id>/cancel/", views.cancel_booking, name="cancel_booking"),
    path("feedback/<int:booking_id>/", views.leave_feedback, name="leave_feedback"),

    # Admin Only
    path("admin/delete_user/<int:user_id>/", views.delete_user, name="delete_user"),
    path("admin/delete_worker/<int:worker_id>/", views.delete_worker, name="delete_worker"),
]




